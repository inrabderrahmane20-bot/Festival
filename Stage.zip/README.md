# Objectif — Event Platform (MVP)

This repository is a detailed, production-minded **MVP** for an event platform called **Objectif** (inspired by the supplied *Cahier des charges*). The implementation contains a **frontend** (React + Vite) and a **backend** (Node/Express) plus sample data and a clear developer README to run it locally.

I read and implemented the app according to the Cahier des charges you uploaded (design, data model and API examples). See the original brief: Cahier_des_charges.pdf. fileciteturn0file0

---
## What you get in this zip
- `frontend/` — React (Vite) single-page app (pages: Home, Programming, Event detail, Speakers, Cart, Admin placeholder)
- `backend/` — Simple Express API serving events and speakers and implementing `/api/cart` and `/api/checkout` (mock)
- `data/` — sample JSON used by backend
- `design/` — quick design tokens & assets notes
- `README` with run instructions and notes

This is an MVP with production-minded structure, clear API contracts, sample data and a stylish UI (CSS-only, responsive). It implements the main features described in the specification: programming listing, filters & search, event page with ticket types, cart with multi-event items and a mock checkout returning an order id and a QR-like code string.

## Quick local run (development)

You need Node.js (v18+) and npm installed.

1. Start backend
```bash
cd backend
npm install
npm run dev   # or `npm start`
```

2. Start frontend
```bash
cd frontend
npm install
npm run dev
```

The frontend expects the backend at `http://localhost:4000`. If you want to change that, edit `frontend/src/config.js`.

## Notes & next steps (ideas)
- SSO / Payment providers are mocked — replace `/api/checkout` with a real gateway (Stripe, Adyen) and implement webhooks.
- PDF ticket generation & QR code generation can be added in backend (libraries: pdfkit, qrcode).
- Add admin UI and authentication for back-office management.
- Add tests (Jest for frontend, supertest/mocha for backend) and CI/CD scripts.

Enjoy — the project package is ready for you to download and run locally.

---
