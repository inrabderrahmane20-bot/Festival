
cd festival-platform-mvp
npm install
npm run seed       # création des données d'exemple dans src/data/db.json
npm start
# ouvrir http://localhost:3000
